package com.android.stubs.b;
public class B
{
public  B() { throw new RuntimeException("Stub!"); }
}
