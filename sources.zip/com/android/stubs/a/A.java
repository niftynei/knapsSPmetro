package com.android.stubs.a;
public abstract class A
  extends com.android.stubs.Parent
  implements com.android.stubs.Parent.Interface, com.android.stubs.a.SomeInterface
{
public class Inner
{
public  Inner() { throw new RuntimeException("Stub!"); }
}
protected  A(int a) { throw new RuntimeException("Stub!"); }
public  com.android.stubs.a.A varargs(com.android.stubs.Parent[]... args) { throw new RuntimeException("Stub!"); }
public  void method() { throw new RuntimeException("Stub!"); }
public abstract  java.lang.String[] stringArrayMethod() throws java.io.IOException;
}
