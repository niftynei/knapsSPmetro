package com.android.stubs.a;
public interface SomeInterface
{
}
